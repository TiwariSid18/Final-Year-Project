
import streamlit as st
import pickle
import string
from nltk.corpus import stopwords
import nltk
import re
from nltk.stem.porter import PorterStemmer
import spacy
from spacy.matcher import Matcher
import mysql.connector

from sklearn.feature_extraction.text import TfidfVectorizer
ps = PorterStemmer()

nlp = spacy.load("en_core_web_sm")
nlp2 = spacy.load("due_date_ner_model")

# Define pattern to match amounts denoted with "Rs."
amount_pattern = [{"LOWER": {"IN": ["rs", "inr", "₹", "rupees"]}}, {"IS_PUNCT": True, "OP": "?"}, {"LIKE_NUM": True}] #, {"LIKE_NUM": True}

# Function to detect amounts (symbol $)
def detect_amounts(text):
    doc = nlp(text)
    amounts = []
    for ent in doc.ents:
        if ent.label_ == "MONEY":
            amounts.append(ent.text)
    return amounts

STOPWORDS = set(stopwords.words('english'))

def clean_text(text):
    # convert to lowercase
    text = text.lower()
    text = re.sub(r'[^0-9a-zA-Z]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    # remove stopwords
    text = " ".join(word for word in text.split() if word not in STOPWORDS)
    return text

tfidf = pickle.load(open('vectorizer3.pkl','rb'))
model = pickle.load(open('model3.pkl','rb'))

st.title("Email/SMS Reminder Classifier")

# Connect to MySQL database
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tiwari1@",
    database="sms_detection"
)

reminder_list = []

input_sms = st.text_area("Enter the message")

if st.button('Submit'):
    transformed_sms = clean_text(input_sms)
    vector_input = tfidf.transform([transformed_sms])
    vector_input = vector_input.toarray()
    result = model.predict(vector_input)[0]
    
    if result == 1:
        st.header("Reminder")
        doc = nlp2(input_sms)
        due_dates = []
        for ent in doc.ents:
            if ent.label_ == "DUE_DATE":
                if ent.start >= 3:
                    preceding_tokens = [doc[i].lower_ for i in range(ent.start - 3, ent.start)]
                    if any(token in preceding_tokens for token in ["due date", "by", "before", "due on", "latest"]):
                        due_dates.append(ent.text)

        amounts = detect_amounts(input_sms)
        doc = nlp(input_sms)
        matcher = Matcher(nlp.vocab)
        matcher.add("Amount", [amount_pattern])
        matches = matcher(doc)
        amounts_rs = []
        for match_id, start, end in matches:
            amounts_rs.append(doc[start:end].text)

        reminder_list.append({"Type": "Reminder", "Message": input_sms, "Due Dates": due_dates, "Amounts": amounts + amounts_rs})
            
    else:
        st.header("Non-Reminder")
        reminder_list.append({"Type": "Non-Reminder", "Message": input_sms, "Due Dates": [], "Amounts": []})

    # Save data to MySQL database
    cursor = mydb.cursor()
    for reminder in reminder_list:
        type_val = reminder["Type"]
        message_val = reminder["Message"]
        due_dates_val = ', '.join(reminder["Due Dates"])
        amounts_val = ', '.join(reminder["Amounts"])

        sql = "INSERT INTO reminders (type, message, due_dates, amounts) VALUES (%s, %s, %s, %s)"
        val = (type_val, message_val, due_dates_val, amounts_val)
        cursor.execute(sql, val)

    mydb.commit()
    cursor.close()

# Display the reminder list
if reminder_list:
    # st.header("Reminder List")
    for reminder in reminder_list:
        st.write("Type:", reminder["Type"])
        st.write("Message:", reminder["Message"])
        st.write("Due Dates:", reminder["Due Dates"])
        st.write("Amounts:", reminder["Amounts"])
else:
    st.write("No reminders submitted yet.")
